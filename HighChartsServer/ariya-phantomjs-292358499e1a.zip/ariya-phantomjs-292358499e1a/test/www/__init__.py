# This file makes test/www/ into a "package" so that
# importing Python response hooks works correctly.
