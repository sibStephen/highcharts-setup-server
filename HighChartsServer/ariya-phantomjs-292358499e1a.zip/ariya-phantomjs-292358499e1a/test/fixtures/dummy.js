module.exports = 'spec/dummy';
