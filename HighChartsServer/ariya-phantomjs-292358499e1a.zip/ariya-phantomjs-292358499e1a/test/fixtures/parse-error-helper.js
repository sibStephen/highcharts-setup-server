var ok;
bar("run away"