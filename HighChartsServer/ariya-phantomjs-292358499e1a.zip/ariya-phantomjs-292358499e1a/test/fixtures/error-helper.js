ErrorHelper = {
    foo: function() {
        this.bar()
    },

    bar: function bar() {
        referenceError
    }
};
