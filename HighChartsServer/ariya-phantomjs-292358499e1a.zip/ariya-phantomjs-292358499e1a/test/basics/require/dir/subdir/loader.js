exports.dummyFile2 = require('dummy_file2');
