exports.fn = function thrower() {
    throw new Error('fn');
};
